<?php

//echo "test"; die; 
if(isset($_POST['contact_submit'])){ 
	
	
	//print_r($_POST); die; 
    $from = $_POST['email']; // this is the sender's Email address	
    $name = $_POST['name'];
	$pname = $_POST['$pname'];
	$phone = $_POST['phone'];
    $email = $_POST['email'];
    $group = implode(",",$_POST['group']);
	$subject = implode(",",$_POST['subject']);
	$sname = $_POST['$sname'];
	//$subject = $_POST['subject'];
	//$textmessage = $_POST['textmessage'];
	
   // $subject ="  Services : " . $service . " " ;
    $message = " Student Full Name : ".$name ."<br/>";
	$message = " Parent Full Name : ".$pname ."<br/>";
	$message .=" Phone Number : " . $phone ."<br/>";
	$message .=" Email ID : ". $email ."<br/>";
	$message .=" Interested Subjects : ".$subject ."<br/>";
	$message .=" Year Group : ".$group ."<br/>";
	$message = " Student's School : ".$sname ."<br/>";
	
	
	//$message .= "";
    //$message .= "This email is coming from companyname Landing Page";
	//$message .="Our team will get in touch with you shortly."."<br/>";
	//$message .="To know more, please connect with us on Twitter, Facebook and LinkedIn."."<br/>";
    //$message .="https://twitter.com/"."<br/>";
	//$message .="https://www.facebook.com/"."<br/>";
	//$message .="https://www.linkedin.com/"."<br/>";
	//$message .="Thank you!"."<br/>";
	//$message .="opaleducation "."<br/>";
	//$message .="opaleducation.com";
		
    include_once("phpmailer.php");
	$headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$mail = new PHPMailer;
	$mail->setFrom($email, $name);
	
	$mail->AddAddress("ramakrishna.ui010@gmail.com", "Rama Krishna");
	
	$mail->addReplyTo($email, $name);
	$mail->isHTML(true);			
	$mail->Subject = $subject;			
	$mail->Body = $message;			
	if ($mail->send()) {
		
		// Email for responder Email
		
	$res_subject = "Thank you for your inquiry. We will get back to you as soon as possible";  // Please add responder email subject
	$res_message=" " . $email . "<br/>";	
	$res_message.="Hello " .$name ." <br/><br/>";
	$res_message.=" " .$pname ." <br/><br/>";	
	$res_message.="Thank you for your inquiry. We will get back to you as soon as possible.";
	
	
		$res_mail = new PHPMailer;
		$res_mail->setFrom("ramakrishna.ui010@gmail.com", "Opal Education");
		$res_mail->AddAddress($email, $name);		
		$res_mail->addReplyTo("ramakrishna.ui010@gmail.com", "Opal Education");		
		$res_mail->isHTML(true);			
		$res_mail->Subject = $res_subject;			
		$res_mail->Body = $res_message;	
		$res_mail->send();
		
		header("location: ../thankyou.html");
	} 
	else {
		header("location: ../fail.html");
	}

}
?>
